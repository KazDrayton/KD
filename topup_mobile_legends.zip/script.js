// Simulasi pengolahan data formulir checkout
document.getElementById('checkoutForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const userId = document.getElementById('id').value;
    const userServer = document.getElementById('server').value;
    const userPayment = document.getElementById('payment').value;

    alert(`Terima kasih, ID: ${userId}\nServer: ${userServer}\nPembayaran via: ${userPayment}\nPembayaran Anda sedang diproses!`);
});
